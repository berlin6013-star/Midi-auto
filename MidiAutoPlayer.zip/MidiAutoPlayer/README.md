# MIDI Auto Player
1. Open this folder in Android Studio, let Gradle sync, Run on your phone.
2. Settings > Accessibility > MIDI Auto Player > enable. (Android 13+ sideloaded: App info > ⋮ > Allow restricted settings first.)
3. In the app: choose a .mid file, set rows/keys, press "Save settings & show floating controls".
4. Open your game's instrument. Press ⌖, tap the first key (top-left) then the last key (bottom-right). Press ▶.
Presets: Sky = 3 rows x 5, diatonic, base 60. Genshin = 3 rows x 7, diatonic, base 60. Piano = 1 row x N, chromatic, base = lowest key's MIDI note.
