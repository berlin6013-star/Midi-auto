# MIDI Auto Player v2
Presets: Sky, Genshin, Piano 15/22/36 white keys. Piano mode taps white keys in a row and black keys between them (higher up).
Floating bar: ▶ play/stop, ⌖ calibrate (grid: 2 taps; piano: first white, last white, any black key), 👁 show/hide key dots.
