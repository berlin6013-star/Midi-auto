package com.example.midiautoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*

class AutoPlayService : AccessibilityService() {
    companion object {
        var instance: AutoPlayService? = null
        @Volatile var song: List<NoteEvent> = emptyList()
    }

    private class Group(val timeMs: Long, val keys: Set<Int>)

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var controls: View? = null
    private var playBtn: Button? = null
    private var playing = false

    override fun onServiceConnected() { instance = this; wm = getSystemService(WINDOW_SERVICE) as WindowManager }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onDestroy() { stop(); hideControls(); instance = null; super.onDestroy() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- playback ----------
    private fun rawKey(n: Int, p: Prefs): Int {
        if (!p.diatonic) return n - p.base
        val deg = intArrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
        fun idx(x: Int) = Math.floorDiv(x, 12) * 7 + deg[Math.floorMod(x, 12)]
        return idx(n) - idx(p.base)
    }

    private fun buildGroups(p: Prefs): List<Group> {
        val total = p.rows * p.cols
        // auto-pick octave shift that fits the most notes on the instrument
        val shift = listOf(0, -12, 12, -24, 24, -36, 36, -48, 48).maxByOrNull { s ->
            song.count { rawKey(it.note + s, p) in 0 until total }
        } ?: 0
        val step = if (p.diatonic) 7 else 12
        val mapped = song.map { ev ->
            var k = rawKey(ev.note + shift, p)
            while (k < 0) k += step
            while (k >= total) k -= step
            ev.timeMs to k.coerceIn(0, total - 1)
        }
        val groups = ArrayList<Group>()
        var i = 0
        while (i < mapped.size) {
            val t0 = mapped[i].first
            val keys = LinkedHashSet<Int>()
            while (i < mapped.size && mapped[i].first - t0 <= 30) { keys.add(mapped[i].second); i++ }
            groups.add(Group(t0, keys))
        }
        return groups
    }

    fun play() {
        stop()
        if (song.isEmpty()) { toast("Load a MIDI file in the app first"); return }
        val p = Prefs(this)
        val groups = buildGroups(p)
        playing = true
        playBtn?.text = "■"
        for (g in groups) handler.postDelayed({ tap(g.keys, p) }, (g.timeMs / p.speed).toLong() + 400)
        handler.postDelayed({ stop() }, ((groups.lastOrNull()?.timeMs ?: 0) / p.speed).toLong() + 1000)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        playing = false
        playBtn?.text = "▶"
    }

    private fun tap(keys: Collection<Int>, p: Prefs) {
        val b = GestureDescription.Builder()
        for (k in keys.take(10)) {
            val col = k % p.cols; val row = k / p.cols
            val fx = if (p.cols > 1) col / (p.cols - 1f) else 0f
            val fy = if (p.rows > 1) row / (p.rows - 1f) else 0f
            val path = Path().apply { moveTo(p.ax + (p.bx - p.ax) * fx, p.ay + (p.by - p.ay) * fy) }
            b.addStroke(GestureDescription.StrokeDescription(path, 0, 20))
        }
        dispatchGesture(b.build(), null, null)
    }

    // ---------- overlays ----------
    fun showControls() {
        if (controls != null) return
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xCC222222.toInt()); setPadding(8, 8, 8, 8) }
        val handle = TextView(this).apply { text = "⠿"; textSize = 22f; setTextColor(Color.WHITE); setPadding(12, 0, 20, 0) }
        val play = Button(this).apply { text = "▶"; setOnClickListener { if (playing) stop() else play() } }
        val cal = Button(this).apply { text = "⌖"; setOnClickListener { calibrate() } }
        val close = Button(this).apply { text = "✕"; setOnClickListener { stop(); hideControls() } }
        playBtn = play
        listOf(handle, play, cal, close).forEach { row.addView(it) }
        val lp = WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, TYPE_ACCESSIBILITY_OVERLAY, FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm?.updateViewLayout(row, lp) }
            }
            true
        }
        wm?.addView(row, lp)
        controls = row
    }

    fun hideControls() {
        controls?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        controls = null; playBtn = null
    }

    /** Tap the first key (top-left), then the last key (bottom-right) of the in-game instrument. */
    fun calibrate() {
        stop()
        val p = Prefs(this)
        var step = 0; var ax = 0f; var ay = 0f
        val root = FrameLayout(this).apply { setBackgroundColor(0x55000000) }
        val label = TextView(this).apply { text = "Tap the FIRST key (top-left)"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER }
        root.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (step == 0) { ax = e.rawX; ay = e.rawY; step = 1; label.text = "Tap the LAST key (bottom-right)" }
                else { p.saveCalibration(ax, ay, e.rawX, e.rawY); wm?.removeView(root); toast("Calibration saved") }
            }
            true
        }
        val lp = WindowManager.LayoutParams(MATCH_PARENT, MATCH_PARENT, TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        wm?.addView(root, lp)
    }
}
