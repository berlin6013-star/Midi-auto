package com.example.midiautoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*

class AutoPlayService : AccessibilityService() {
    companion object {
        var instance: AutoPlayService? = null
        @Volatile var song: List<NoteEvent> = emptyList()
        private val WHITE_DEG = intArrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
        private val IS_BLACK = booleanArrayOf(false, true, false, true, false, false, true, false, true, false, true, false)
    }

    private class Chord(val timeMs: Long, val pts: List<PointF>)

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var controls: View? = null
    private var markers: View? = null
    private var playBtn: Button? = null
    private var playing = false

    override fun onServiceConnected() { instance = this; wm = getSystemService(WINDOW_SERVICE) as WindowManager }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onDestroy() { stop(); hideMarkers(); hideControls(); instance = null; super.onDestroy() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- note -> screen position ----------
    private fun whiteIdx(n: Int) = Math.floorDiv(n, 12) * 7 + WHITE_DEG[Math.floorMod(n, 12)]

    private fun rawIndex(n: Int, p: Prefs): Int =
        if (p.piano) whiteIdx(n) - whiteIdx(p.base)
        else if (p.diatonic) whiteIdx(n) - whiteIdx(p.base)
        else n - p.base

    private fun ok(n: Int, p: Prefs): Boolean {
        val i = rawIndex(n, p)
        return if (p.piano) {
            val black = IS_BLACK[Math.floorMod(n, 12)]
            i in 0 until (if (black) p.cols - 1 else p.cols)
        } else i in 0 until p.rows * p.cols
    }

    /** Shift a note by octaves until it lands on the instrument; null if impossible. */
    private fun fit(n0: Int, p: Prefs): Int? {
        var n = n0
        repeat(20) {
            if (ok(n, p)) return n
            n += if (rawIndex(n, p) < 0) 12 else -12
        }
        return null
    }

    private fun gridPoint(k: Int, p: Prefs): PointF {
        val col = k % p.cols
        var row = k / p.cols
        if (p.flip) row = p.rows - 1 - row
        val fx = if (p.cols > 1) col / (p.cols - 1f) else 0f
        val fy = if (p.rows > 1) row / (p.rows - 1f) else 0f
        return PointF(p.ax + (p.bx - p.ax) * fx, p.ay + (p.by - p.ay) * fy)
    }

    private fun pianoPoint(i: Int, black: Boolean, p: Prefs): PointF {
        val step = if (p.cols > 1) (p.bx - p.ax) / (p.cols - 1) else 0f
        val x = p.ax + step * i
        return if (black) PointF(x + step / 2, p.blackY) else PointF(x, p.ay)
    }

    private fun point(n: Int, p: Prefs): PointF {
        val i = rawIndex(n, p)
        return if (p.piano) pianoPoint(i, IS_BLACK[Math.floorMod(n, 12)], p) else gridPoint(i, p)
    }

    /** Every key position, for the on-screen preview. Third value = black key. */
    private fun allPoints(p: Prefs): List<Triple<Float, Float, Boolean>> {
        val out = ArrayList<Triple<Float, Float, Boolean>>()
        if (p.piano) {
            val d0 = whiteIdx(p.base)
            for (i in 0 until p.cols) {
                val w = pianoPoint(i, false, p); out.add(Triple(w.x, w.y, false))
                val d = Math.floorMod(d0 + i, 7)
                if (i < p.cols - 1 && d != 2 && d != 6) { val b = pianoPoint(i, true, p); out.add(Triple(b.x, b.y, true)) }
            }
        } else for (k in 0 until p.rows * p.cols) { val g = gridPoint(k, p); out.add(Triple(g.x, g.y, false)) }
        return out
    }

    // ---------- playback ----------
    private fun buildChords(p: Prefs): List<Chord> {
        val shift = listOf(0, -12, 12, -24, 24, -36, 36, -48, 48).maxByOrNull { s ->
            song.count { ok(it.note + s, p) }
        } ?: 0
        val mapped = ArrayList<Pair<Long, PointF>>()
        for (ev in song) {
            val n = fit(ev.note + shift, p) ?: continue
            mapped.add(ev.timeMs to point(n, p))
        }
        val chords = ArrayList<Chord>()
        var i = 0
        while (i < mapped.size) {
            val t0 = mapped[i].first
            val pts = LinkedHashMap<String, PointF>()
            while (i < mapped.size && mapped[i].first - t0 <= 30) {
                val q = mapped[i].second
                pts["${q.x.toInt()},${q.y.toInt()}"] = q; i++
            }
            chords.add(Chord(t0, pts.values.toList()))
        }
        return chords
    }

    fun play() {
        stop()
        if (song.isEmpty()) { toast("Load a MIDI file in the app first"); return }
        val p = Prefs(this)
        val chords = buildChords(p)
        playing = true
        playBtn?.text = "■"
        for (c in chords) handler.postDelayed({ tap(c.pts) }, (c.timeMs / p.speed).toLong() + 400)
        handler.postDelayed({ stop() }, ((chords.lastOrNull()?.timeMs ?: 0) / p.speed).toLong() + 1000)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        playing = false
        playBtn?.text = "▶"
    }

    private fun tap(pts: List<PointF>) {
        val b = GestureDescription.Builder()
        for (q in pts.take(10)) {
            val path = Path().apply { moveTo(q.x, q.y) }
            b.addStroke(GestureDescription.StrokeDescription(path, 0, 20))
        }
        dispatchGesture(b.build(), null, null)
    }

    // ---------- overlays ----------
    fun showControls() {
        if (controls != null) return
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xCC222222.toInt()); setPadding(8, 8, 8, 8) }
        val handle = TextView(this).apply { text = "⠿"; textSize = 22f; setTextColor(Color.WHITE); setPadding(12, 0, 20, 0) }
        val play = Button(this).apply { text = "▶"; setOnClickListener { if (playing) stop() else play() } }
        val cal = Button(this).apply { text = "⌖"; setOnClickListener { calibrate() } }
        val eye = Button(this).apply { text = "👁"; setOnClickListener { if (markers != null) hideMarkers() else showMarkers() } }
        val close = Button(this).apply { text = "✕"; setOnClickListener { stop(); hideMarkers(); hideControls() } }
        playBtn = play
        listOf(handle, play, cal, eye, close).forEach { row.addView(it) }
        val lp = WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, TYPE_ACCESSIBILITY_OVERLAY, FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm?.updateViewLayout(row, lp) }
            }
            true
        }
        wm?.addView(row, lp)
        controls = row
    }

    fun hideControls() {
        controls?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        controls = null; playBtn = null
    }

    /** Draws a dot on every key position: red = white/normal key, blue = black key. Touches pass through. */
    fun showMarkers() {
        hideMarkers()
        val pts = allPoints(Prefs(this))
        val red = Paint().apply { color = Color.RED; isAntiAlias = true }
        val blue = Paint().apply { color = Color.rgb(30, 120, 255); isAntiAlias = true }
        val ring = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        val v = object : View(this) {
            override fun onDraw(c: Canvas) {
                val loc = IntArray(2); getLocationOnScreen(loc)
                for ((x, y, black) in pts) {
                    c.drawCircle(x - loc[0], y - loc[1], 17f, ring)
                    c.drawCircle(x - loc[0], y - loc[1], 12f, if (black) blue else red)
                }
            }
        }
        val lp = WindowManager.LayoutParams(MATCH_PARENT, MATCH_PARENT, TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCHABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        wm?.addView(v, lp)
        markers = v
    }

    fun hideMarkers() {
        markers?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        markers = null
    }

    /** Grid: tap first key (top-left), last key (bottom-right). Piano: first white, last white, any black key. */
    fun calibrate() {
        stop(); hideMarkers()
        val p = Prefs(this)
        val labels = if (p.piano)
            listOf("Tap the FIRST white key (far left)", "Tap the LAST white key (far right)", "Tap any BLACK key")
        else listOf("Tap the FIRST key (top-left)", "Tap the LAST key (bottom-right)")
        val xs = FloatArray(3); val ys = FloatArray(3); var step = 0
        val root = FrameLayout(this).apply { setBackgroundColor(0x55000000) }
        val label = TextView(this).apply { text = labels[0]; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER }
        root.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                xs[step] = e.rawX; ys[step] = e.rawY; step++
                if (step < labels.size) label.text = labels[step]
                else {
                    if (p.piano) { p.ax = xs[0]; p.ay = ys[0]; p.bx = xs[1]; p.by = ys[0]; p.blackY = ys[2] }
                    else p.saveCalibration(xs[0], ys[0], xs[1], ys[1])
                    wm?.removeView(root)
                    toast("Saved. Dots show where taps will land")
                    showMarkers()
                }
            }
            true
        }
        val lp = WindowManager.LayoutParams(MATCH_PARENT, MATCH_PARENT, TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        wm?.addView(root, lp)
    }
}
