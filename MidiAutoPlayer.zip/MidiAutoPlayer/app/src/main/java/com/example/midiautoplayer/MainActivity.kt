package com.example.midiautoplayer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var rows: EditText
    private lateinit var cols: EditText
    private lateinit var base: EditText
    private lateinit var speed: EditText
    private lateinit var dia: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Prefs(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; col.addView(this) }
        fun field(label: String, v: String, decimal: Boolean = false): EditText {
            col.addView(TextView(this).apply { text = label })
            return EditText(this).apply {
                setText(v); inputType = InputType.TYPE_CLASS_NUMBER or if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0
                col.addView(this)
            }
        }
        status = TextView(this).apply { text = "No MIDI loaded"; textSize = 16f }
        col.addView(status)
        btn("1. Enable accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Choose MIDI file") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)
        }
        rows = field("Instrument rows (Sky: 3, piano: 1)", p.rows.toString())
        cols = field("Keys per row (Sky: 5, Genshin: 7, piano: 15/21/36)", p.cols.toString())
        base = field("Lowest key as MIDI note (60 = C4)", p.base.toString())
        speed = field("Speed (1.0 = normal)", p.speed.toString(), true)
        dia = CheckBox(this).apply { text = "Diatonic keys (Sky/Genshin). Untick for chromatic piano."; isChecked = p.diatonic; col.addView(this) }
        btn("3. Save settings & show floating controls") {
            p.rows = rows.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 3
            p.cols = cols.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 5
            p.base = base.text.toString().toIntOrNull() ?: 60
            p.speed = speed.text.toString().toFloatOrNull()?.coerceIn(0.1f, 4f) ?: 1f
            p.diatonic = dia.isChecked
            val s = AutoPlayService.instance
            if (s == null) toast("Enable the accessibility service first") else { s.showControls(); toast("Open your game, press ⌖ to calibrate, ▶ to play") }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val notes = MidiParser.parse(bytes)
                AutoPlayService.song = notes
                runOnUiThread { status.text = "Loaded ${notes.size} notes (${(notes.lastOrNull()?.timeMs ?: 0) / 1000}s)" }
            } catch (e: Exception) { runOnUiThread { status.text = "Failed: ${e.message}" } }
        }.start()
    }
}
