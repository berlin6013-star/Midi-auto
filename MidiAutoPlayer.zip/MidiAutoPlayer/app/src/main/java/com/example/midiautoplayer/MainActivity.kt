package com.example.midiautoplayer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var status: TextView
    private lateinit var rows: EditText
    private lateinit var cols: EditText
    private lateinit var base: EditText
    private lateinit var speed: EditText
    private lateinit var dia: CheckBox
    private lateinit var flip: CheckBox
    private lateinit var piano: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; col.addView(this) }
        fun field(label: String, v: String, decimal: Boolean = false): EditText {
            col.addView(TextView(this).apply { text = label })
            return EditText(this).apply {
                setText(v); inputType = InputType.TYPE_CLASS_NUMBER or if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0
                col.addView(this)
            }
        }
        fun presetRow(vararg items: Pair<String, String>) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((label, key) in items) r.addView(Button(this).apply {
                text = label; setOnClickListener { applyPreset(key) }
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            col.addView(r)
        }
        status = TextView(this).apply { text = "No MIDI loaded"; textSize = 16f }
        col.addView(status)
        btn("1. Enable accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Choose MIDI file") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)
        }
        col.addView(TextView(this).apply { text = "\n3. Pick a preset (then fine-tune below):"; textSize = 15f })
        presetRow("Sky" to "sky", "Genshin" to "genshin")
        presetRow("Piano 15" to "p15", "Piano 22" to "p22", "Piano 36" to "p36")
        rows = field("Rows (games: 3, piano ignores this)", p.rows.toString())
        cols = field("Keys per row (piano: number of WHITE keys)", p.cols.toString())
        base = field("First key as MIDI note (60 = C4; piano: a white key)", p.base.toString())
        speed = field("Speed (1.0 = normal)", p.speed.toString(), true)
        piano = CheckBox(this).apply { text = "Piano layout (white + black keys)"; isChecked = p.piano; col.addView(this) }
        dia = CheckBox(this).apply { text = "Diatonic grid (Sky/Genshin)"; isChecked = p.diatonic; col.addView(this) }
        flip = CheckBox(this).apply { text = "Flip rows (lowest notes on bottom row)"; isChecked = p.flip; col.addView(this) }
        btn("4. Save & show floating controls") {
            save()
            val s = AutoPlayService.instance
            if (s == null) toast("Enable the accessibility service first")
            else { s.showControls(); toast("Open your game, press ⌖ to calibrate, 👁 to see key dots, ▶ to play") }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun save() {
        p.rows = rows.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 3
        p.cols = cols.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 5
        p.base = base.text.toString().toIntOrNull() ?: 60
        p.speed = speed.text.toString().toFloatOrNull()?.coerceIn(0.1f, 4f) ?: 1f
        p.piano = piano.isChecked; p.diatonic = dia.isChecked; p.flip = flip.isChecked
    }

    /** Presets also set rough default key positions for a landscape screen; fix them with the calibrate button. */
    private fun applyPreset(key: String) {
        val dm = resources.displayMetrics
        val w = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
        val h = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        fun grid(r: Int, c: Int, bs: Int, fl: Boolean, x1: Float, y1: Float, x2: Float, y2: Float) {
            p.piano = false; p.diatonic = true; p.rows = r; p.cols = c; p.base = bs; p.flip = fl
            p.ax = x1 * w; p.ay = y1 * h; p.bx = x2 * w; p.by = y2 * h
        }
        fun pno(whites: Int, bs: Int) {
            p.piano = true; p.diatonic = false; p.flip = false; p.rows = 1; p.cols = whites; p.base = bs
            p.ax = 0.10f * w; p.bx = 0.90f * w; p.ay = 0.82f * h; p.by = 0.82f * h; p.blackY = 0.60f * h
        }
        when (key) {
            "sky" -> grid(3, 5, 60, false, 0.36f, 0.34f, 0.64f, 0.72f)
            "genshin" -> grid(3, 7, 48, true, 0.30f, 0.36f, 0.70f, 0.80f)
            "p15" -> pno(15, 60)
            "p22" -> pno(22, 48)
            "p36" -> pno(36, 36)
        }
        rows.setText(p.rows.toString()); cols.setText(p.cols.toString()); base.setText(p.base.toString())
        piano.isChecked = p.piano; dia.isChecked = p.diatonic; flip.isChecked = p.flip
        toast("Preset applied. Show floating controls, then press 👁 to check and ⌖ to adjust")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val notes = MidiParser.parse(bytes)
                AutoPlayService.song = notes
                runOnUiThread { status.text = "Loaded ${notes.size} notes (${(notes.lastOrNull()?.timeMs ?: 0) / 1000}s)" }
            } catch (e: Exception) { runOnUiThread { status.text = "Failed: ${e.message}" } }
        }.start()
    }
}
