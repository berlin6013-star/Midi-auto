package com.example.midiautoplayer

data class NoteEvent(val timeMs: Long, val note: Int)

object MidiParser {
    /** Parses a Standard MIDI File into note-on events (drums on channel 10 ignored), with tempo changes applied. */
    fun parse(data: ByteArray): List<NoteEvent> {
        var pos = 0
        fun u8() = data[pos++].toInt() and 0xFF
        fun u16() = (u8() shl 8) or u8()
        fun u32() = (u16() shl 16) or u16()
        fun id(): String { val s = String(data, pos, 4, Charsets.ISO_8859_1); pos += 4; return s }
        fun varLen(): Int { var v = 0; do { val b = u8(); v = (v shl 7) or (b and 0x7F); if (b and 0x80 == 0) break } while (true); return v }

        require(id() == "MThd") { "Not a MIDI file" }
        u32(); u16()
        val nTracks = u16()
        val div = u16()
        require(div and 0x8000 == 0) { "SMPTE timing not supported" }

        val notes = ArrayList<Pair<Long, Int>>()
        val tempos = ArrayList<Pair<Long, Int>>()
        repeat(nTracks) {
            if (pos + 8 > data.size) return@repeat
            val cid = id(); val len = u32(); val end = pos + len
            if (cid == "MTrk") {
                var tick = 0L; var status = 0
                while (pos < end) {
                    tick += varLen().toLong()
                    var s = u8()
                    if (s < 0x80) { pos--; s = status } else if (s < 0xF0) status = s
                    when (s) {
                        0xFF -> {
                            val type = u8(); val l = varLen()
                            if (type == 0x51 && l == 3) {
                                val us = ((data[pos].toInt() and 0xFF) shl 16) or ((data[pos + 1].toInt() and 0xFF) shl 8) or (data[pos + 2].toInt() and 0xFF)
                                tempos.add(tick to us)
                            }
                            pos += l
                        }
                        0xF0, 0xF7 -> pos += varLen()
                        else -> {
                            val hi = s and 0xF0
                            val d1 = u8()
                            val d2 = if (hi == 0xC0 || hi == 0xD0) 0 else u8()
                            if (hi == 0x90 && d2 > 0 && (s and 0x0F) != 9) notes.add(tick to d1)
                        }
                    }
                }
            }
            pos = end
        }

        tempos.sortBy { it.first }
        if (tempos.isEmpty() || tempos[0].first > 0) tempos.add(0, 0L to 500000)
        val segMs = DoubleArray(tempos.size)
        for (i in 1 until tempos.size)
            segMs[i] = segMs[i - 1] + (tempos[i].first - tempos[i - 1].first) * tempos[i - 1].second / 1000.0 / div
        notes.sortBy { it.first }
        var i = 0
        return notes.map { (t, n) ->
            while (i + 1 < tempos.size && tempos[i + 1].first <= t) i++
            NoteEvent((segMs[i] + (t - tempos[i].first) * tempos[i].second / 1000.0 / div).toLong(), n)
        }
    }
}
