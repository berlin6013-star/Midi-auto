package com.example.midiautoplayer

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var ax get() = sp.getFloat("ax", 200f); set(v) = sp.edit().putFloat("ax", v).apply()
    var ay get() = sp.getFloat("ay", 600f); set(v) = sp.edit().putFloat("ay", v).apply()
    var bx get() = sp.getFloat("bx", 900f); set(v) = sp.edit().putFloat("bx", v).apply()
    var by get() = sp.getFloat("by", 900f); set(v) = sp.edit().putFloat("by", v).apply()
    var rows get() = sp.getInt("rows", 3); set(v) = sp.edit().putInt("rows", v).apply()
    var cols get() = sp.getInt("cols", 5); set(v) = sp.edit().putInt("cols", v).apply()
    /** MIDI number of the first key (60 = C4) */
    var base get() = sp.getInt("base", 60); set(v) = sp.edit().putInt("base", v).apply()
    /** true: keys are white-key scale steps (Sky/Genshin style). false: chromatic (semitone per key). */
    var diatonic get() = sp.getBoolean("dia", true); set(v) = sp.edit().putBoolean("dia", v).apply()
    var speed get() = sp.getFloat("speed", 1f); set(v) = sp.edit().putFloat("speed", v).apply()
    fun saveCalibration(x1: Float, y1: Float, x2: Float, y2: Float) { ax = x1; ay = y1; bx = x2; by = y2 }
}
