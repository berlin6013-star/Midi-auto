package com.example.midiautoplayer

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    /** First key position (grid: top-left key; piano: first white key) */
    var ax get() = sp.getFloat("ax", 200f); set(v) = sp.edit().putFloat("ax", v).apply()
    var ay get() = sp.getFloat("ay", 600f); set(v) = sp.edit().putFloat("ay", v).apply()
    /** Last key position (grid: bottom-right key; piano: last white key) */
    var bx get() = sp.getFloat("bx", 900f); set(v) = sp.edit().putFloat("bx", v).apply()
    var by get() = sp.getFloat("by", 900f); set(v) = sp.edit().putFloat("by", v).apply()
    /** Piano only: screen Y where black keys are tapped */
    var blackY get() = sp.getFloat("blackY", 450f); set(v) = sp.edit().putFloat("blackY", v).apply()
    var rows get() = sp.getInt("rows", 3); set(v) = sp.edit().putInt("rows", v).apply()
    /** Grid: keys per row. Piano: number of WHITE keys. */
    var cols get() = sp.getInt("cols", 5); set(v) = sp.edit().putInt("cols", v).apply()
    /** MIDI number of the first key (60 = C4). For piano it should be a white key. */
    var base get() = sp.getInt("base", 60); set(v) = sp.edit().putInt("base", v).apply()
    var diatonic get() = sp.getBoolean("dia", true); set(v) = sp.edit().putBoolean("dia", v).apply()
    /** Real piano layout: white keys in a row, black keys between them, higher up. */
    var piano get() = sp.getBoolean("piano", false); set(v) = sp.edit().putBoolean("piano", v).apply()
    /** Grid only: lowest notes on the bottom row instead of the top row. */
    var flip get() = sp.getBoolean("flip", false); set(v) = sp.edit().putBoolean("flip", v).apply()
    var speed get() = sp.getFloat("speed", 1f); set(v) = sp.edit().putFloat("speed", v).apply()
    fun saveCalibration(x1: Float, y1: Float, x2: Float, y2: Float) { ax = x1; ay = y1; bx = x2; by = y2 }
}
